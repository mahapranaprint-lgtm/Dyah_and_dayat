UNDANGAN DIGITAL DYAH & DAYAT
=============================

Cara publish ke GitHub Pages:
1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub, misalnya: undangan-dyah-dayat
3. Upload index.html serta folder assets dan musik ke root repository.
4. Buka Settings > Pages.
5. Pada Build and deployment pilih Deploy from a branch.
6. Pilih branch main dan folder /(root), lalu Save.
7. Tunggu beberapa menit sampai GitHub Pages memberi alamat website.

Foto:
- assets/foto-cover.jpg adalah foto pasangan yang Anda kirim.

Musik:
- Masukkan file musik MP3 pilihan Anda ke folder musik.
- Ganti nama file menjadi lagu.mp3 sehingga path-nya tepat: musik/lagu.mp3.
- Tidak ada tombol musik di halaman.
- Pemutaran dicoba otomatis ketika tamu menekan tombol "Buka Undangan". Browser umumnya tidak mengizinkan suara autoplay sebelum ada interaksi pengguna, jadi cara ini paling kompatibel.
- File lagu.mp3 belum disertakan; tambahkan sendiri sesuai rencana.

Data undangan mengikuti desain yang dikirim. Tautan peta menggunakan pencarian umum Desa Tri Tunggal, Sematu Jaya, Lamandau; sesuaikan dengan pin lokasi yang tepat jika ada.
